//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GuidGen.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDD_GUIDGEN_DIALOG              102
#define IDP_ERR_INIT_OLE                102
#define IDS_FORMATS                     104
#define IDS_STRING105                   105
#define IDS_STRING106                   106
#define IDS_STRING107                   107
#define IDR_MAINFRAME                   128
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_RADIO4                      1003
#define IDC_RESULTS                     1004
#define IDC_NEWGUID                     1005
#define IDP_ERR_CREATE_GUID             2000
#define IDP_ERR_OPEN_CLIP               2001
#define IDS_ABOUTBOX                    2002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
