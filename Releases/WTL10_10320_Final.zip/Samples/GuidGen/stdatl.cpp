// stdatl.cpp : source file that includes just the standard includes
//	GuidGen.pch will be the pre-compiled header
//	stdatl.obj will contain the pre-compiled type information

#include "stdatl.h"
