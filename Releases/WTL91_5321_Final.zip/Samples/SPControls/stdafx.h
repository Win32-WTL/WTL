// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

// Change these values to use different versions
#define WINVER		0x0420

#include <atlbase.h>
#include <atlapp.h>

extern CAppModule _Module;

#include <atlwin.h>

#include <aygshell.h>
#include <tpcshell.h>
#pragma comment(lib, "aygshell.lib")

