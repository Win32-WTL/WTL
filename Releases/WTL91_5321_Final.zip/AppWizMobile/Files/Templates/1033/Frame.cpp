// [!output WTL_APPWND_FILE].cpp : implementation of the [!output WTL_FRAME_CLASS] class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//?ppc
#include "resourceppc.h"
//?sp
#include "resourcesp.h"
//?end

#include "aboutdlg.h"
[!if WTL_USE_VIEW_CLASS]
#include "[!output WTL_VIEW_FILE].h"
[!endif]
#include "[!output WTL_APPWND_FILE].h"

